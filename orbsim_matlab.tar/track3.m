% MATLAB program to compute the sunlit groundtrack for the 
%   Orbital Carbon Observatory (OCO) spacecraft.
%
% David F. Baker  dfb@ucar.edu
%

% User should input:
%  - initial true anomaly, vo.  Use -90 deg to start N-bound pass at equator
%  - solar elevation angle off equator for time of year
%  - local time of ascending node (currently set = 10.7 hours = 1.3pm)

% Integration starts at 0:00 GMT

  clear;
  clf;

% load and plot coastline
  load coast;
  ll=coast;
  plot(ll(:,2),ll(:,1))
  hold on;

  axis([-180 180 -90 90]);
  set(gca,'XTick',[-180 -120 -60 0 60 120 180]);
  set(gca,'XTicklabel',str2mat('180W','120W','60W','0','60E','120E','180E'));
  set(gca,'YTick',[-90 -60 -30 0 30 60 90]);
  set(gca,'YTicklabel',str2mat('90S','60S','30S','0','30N','60N','90N'));

% set angular constants
  pi = 3.141596;
  twopi = 2.*pi;
  dr = pi/180.;
  eqrad = 6378.145;
% eearth = 0.0
  eearth = 0.08182;
  eearthfact = 1.0 - eearth*eearth;

% angle past 90 degrees that sun is still illuminating ground
  SZAcutoff_nadir = 80.;
% SZAcutoff_nadir = 75.;
% SZAcutoff_nadir = 90.;
  SZAcutoff_glint = 80.;
% SZAcutoff_glint = 90.;

% set OCO orbital elements 
  semi = 7083.4456;
  eccen = 0.0012;
% argp = pi/2.;
% for ascending node at 1:18 pm
% node = 10.7;
  node =  1.3;
% node =   .0;
  inc = 98.2*dr;
% inc = 90.0*dr;
  vo = -90.*dr
% vo is the true anomaly at 0:00 GMT  -- make it positive here...
  if vo < 0.;
     vo = vo + twopi;
  end;
  si = sin(inc);
  ci = cos(inc);

% set Earth parameters
  rate = twopi/24./3600.;
  mu = 398601.2;
  param = sqrt(mu/semi^3) ;


% argp = pi/2 assumed here
  cvo = cos(vo);
  svo = sin(vo);
  cEo = (eccen+cvo)/(1.+eccen*cvo);
  sEo = sqrt(1.-cEo*cEo);
  sEo = sEo * sign(svo);
  Eo = atan2(sEo,cEo);
  Mo = Eo - eccen*sEo;

  ilit=0.;
% Time loop
%
% tstep =  90 second step size for plotting
% Assume time zero is at 12:00 noon, Greenwich   
% day1 = Jan 1 
% for day = 355:355;    % NH winter solstice
% for day = 172:172;    % NH summer solstice
  for day =  80: 80;    % for March 21 (equinox)
% for day = 263:263;    % for Sept 21 (equinox)
% for day = 1:1;

  solarincl =-23.5*dr*cos((day-1+11)/365.*twopi);
  csol = cos(solarincl);
  ssol = sin(solarincl);

% tstep = 90.;
  tstep = 20.;
  stepsperday = 86400./tstep;
  for td = 1: stepsperday;
    td 
    t = (day-1)*stepsperday + td;
    tsec = (t-1)*tstep; 
%   rotation angle of Earth in solar frame
    w = rate*(tsec - node*3600.);
    cw = cos(w);
    sw = sin(w);

%   compute the mean, eccentric, and true anomalies at time t
    Mbig = tsec*param +Mo;
    M = rem(Mbig,twopi);
    E1 = M + eccen*sin(M);
    M1 = E1-eccen*sin(E1);
    E2 = E1 - (M1-M)/(1.-eccen*cos(E1));
    M2 = E1-eccen*sin(E1);
    [ E1, E2, M1, M2, M, Mbig, Mo]; 
    E=E2;
    cE = cos(E);
    sE = sin(E);
    cv = (cE-eccen)/(1.-eccen*cE);
    sv = sqrt(1.-cv*cv)*sign(sE);

%   compute the x, y, and z coordinates of the s/c in rotating Earth frame
    x0 = -semi*sv;
    y0 =  semi*cv;
    z0 = 0.;
    x = cw*x0 + sw*ci*y0 - sw*si*z0;
    y =-sw*x0 + cw*ci*y0 - cw*si*z0;
    z =            si*y0 +    ci*z0;

%   save only those points in the sunlit portion
    rho2 = x*x+y*y;
    r2 = z*z + rho2;
    r  = sqrt(r2);
%   solar position in rotating Earth frame
    wsun = rate*tsec;
    xsun = cos(wsun)*csol;
    ysun =-sin(wsun)*csol;
    zsun =           ssol;
    sundot_nadir = (x*xsun + y*ysun + z*zsun)/r;
    sza = acos(sundot_nadir);
%
    glintmode = 0;
%   glintmode = 1;

   
%   Nadir-pointing mode
    long(t) = atan2(y,x)/dr;
    lat(t)  = atan2(z,sqrt(rho2))/dr;

    if glintmode == 0 ;

    if sundot_nadir > cos( SZAcutoff_nadir*dr );
      ilit = ilit+1;
      nadirlong(ilit) = long(t);
      nadirlat( ilit) =  lat(t);
      sunlong(ilit) = atan2(ysun,xsun)/dr;
      sunlat(ilit)  = atan2(zsun,sqrt(xsun*xsun+ysun*ysun))/dr;
      glintlong(ilit) = long(t);
      glintlat( ilit) =  lat(t);
    end;

    else
%
%   Glint-pointing mode
    usun = [ xsun, ysun, zsun ]; 
     sat = [ x, y, z ];
    usat = sat/r; 
% get normal at surface under the satellite
    geodlat = atan2(usat(3)/eearthfact, sqrt((1.-usat(3))*(1.+usat(3))) ); 
    geodlon = atan2(usat(2),usat(1));
    satgeod(1)=cos(geodlat)*cos(geodlon);
    satgeod(2)=cos(geodlat)*sin(geodlon);
    satgeod(3)=sin(geodlat);
    satgeod;
%   find the glint vector with a bisection method
    c1=0.;
    c2=1.; 
    for it = 1:25  
       it;
%   DO WHILE (ABS(c1-c2).GT.ErrorTol)
       c3=(c1+c2)/2.;
%      satgeod
%      usun
       fovnorm=c3*satgeod+(1-c3)*usun;
       fovnorm2 = dot(fovnorm,fovnorm);
       fovnorm1 = sqrt(fovnorm2);
       ufovnorm = fovnorm/fovnorm1;
%      get position vector corresponding to this normal
       fov(1) = ufovnorm(1);
       fov(2) = ufovnorm(2);
       fov(3) = ufovnorm(3)*eearthfact;
       fov2 = dot(fov,fov);
       ufov = fov/sqrt(fov2);
%      get Earth radius in direction of ufov
       efact = eearth*ufov(3);
       rsurf = eqrad/sqrt(1.0+efact*efact/eearthfact);
%      r
%      sat
       GeoFov = rsurf*ufov;
       FovSat=sat - GeoFov;
       SatFov2 = dot(FovSat,FovSat);
       SatFov1 = sqrt(SatFov2);
       uFovSat = FovSat/SatFov1;
       dot1 = dot(ufovnorm, uFovSat);
       dot2 = dot(ufovnorm, usun);
       dot3 = dot(usun,     uFovSat);
       dot4 = 1.0 - dot(ufovnorm, ufov);
       if dot1 < dot2; 
          c1=c3;
       else
          c2=c3;
       end 
%      pause
    end
%   usun
%   usat
%   satgeod
%   ufovnorm
%   ufov
%   acos(dot1), acos(dot2), acos(dot3)/2.
%   pause
    dot4;
    glong(t) = atan2(ufov(2),ufov(1))/dr;
    glat(t)  = asin(ufov(3))/dr;
    sundot_glint = dot2;
    if sundot_glint > cos( SZAcutoff_glint*dr );  % use this
%   if sundot_nadir > cos( SZAcutoff_glint*dr );
      ilit = ilit+1;
      glintlong(ilit) = glong(t);
      glintlat( ilit) = glat( t);
      normlong(ilit) = atan2(ufovnorm(2),ufovnorm(1))/dr;
      normlat(ilit) = asin(ufovnorm(3))/dr;
      fovsclong(ilit) = atan2(uFovSat(2),uFovSat(1))/dr;
      fovsclat(ilit) = asin(uFovSat(3))/dr;
      if sundot_nadir > cos( SZAcutoff_glint*dr );
        nadirlong(ilit) = long(t);
        nadirlat( ilit) =  lat(t);
        ndarklong(ilit) = NaN;
        ndarklat( ilit) = NaN;
      else
        ndarklong(ilit) = long(t);
        ndarklat( ilit) =  lat(t);
        nadirlong(ilit) = NaN;
        nadirlat( ilit) = NaN;
      end 
      sunlong(ilit) = atan2(ysun,xsun)/dr;
      sunlat(ilit)  = atan2(zsun,sqrt(xsun*xsun+ysun*ysun))/dr;
      colorglat(ilit,1:4) = NaN*ones(1,4);
      colorglon(ilit,1:4) = NaN*ones(1,4);
      SZA_glint = acos(sundot_glint)/dr
      iSZA_glint = floor( SZA_glint / (90/4) ) + 1;
      colorglat(ilit,iSZA_glint) = glintlat(ilit);
      colorglon(ilit,iSZA_glint) = glintlong(ilit);
    end;

    end; 

%   pause
  end;
 plot(nadirlong,nadirlat,'r.')    % nadir; turn off call to glint above:  set glintmode=0
%plot(glintlong,glintlat,'b.')    % glint;                                set glintmode=1
% plot sunlit groundtrack
%plot(colorglon(:,1),colorglat(:,1),'b.',colorglon(:,2),colorglat(:,2),'c.',colorglon(:,3),colorglat(:,3),'m.',colorglon(:,4),colorglat(:,4),'r.')
%plot(nadirlong,nadirlat,'k.',colorglon(:,1),colorglat(:,1),'b.',colorglon(:,2),colorglat(:,2),'c.',colorglon(:,3),colorglat(:,3),'m.',colorglon(:,4),colorglat(:,4),'r.')
%  Use this next line to plot both nadir and glint tracks
%plot(nadirlong,nadirlat,'k*',ndarklong,ndarklat,'r*',glintlong,glintlat,'bo')
%plot(nadirlong,nadirlat,'k.',glintlong,glintlat,'r.',sunlong,sunlat,'b.')
%plot(nadirlong,nadirlat,'k.',glintlong,glintlat,'r.',sunlong,sunlat,'r.',normlong,normlat,'b.')
%plot(nadirlong,nadirlat,'g.',glintlong,glintlat,'b.',sunlong,sunlat,'r.',fovsclong,fovsclat,'m.')
%plot(nadirlong,nadirlat,'g.',glintlong,glintlat,'b.',sunlong,sunlat,'r.',normlong,normlat,'c.',fovsclong,fovsclat,'m.')
 set(gca,'XTick',[-180:20.:180])
 set(gca,'XTickLabel',[-180:20:180]);
 set(gca,'YTick',[-90:12.:90])
 set(gca,'YTickLabel',[-90:12:90]);
%set(gca,'XMinorTick',[-180:10.:180])
%set(gca,'YMinorTick',[-90:6.:90])
 set(gca,'XMinorGrid','On')
 set(gca,'YMinorGrid','On')
 axis([-180. 180. -90. 90. ]);
%plot(long,   lat,   'r.')
%axis([-180. 180. -90. 90. ]);
%plot(long(t),lat(t),'go')
%axis([-180. 180. -90. 90. ]);
%set(gca,'XTick',[-180:10.:180])
%print -dpsc  OCOorb_10d.ps; 
 print -dpsc  OCOorb_both.ps;
pause;
 clf;
 end;
