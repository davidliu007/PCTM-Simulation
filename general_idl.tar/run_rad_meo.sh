#!/bin/sh

idl << eof 
.comp radview_meo_fix
.run radview_fix_yr_run.pro
eof
