#!/bin/sh

idl << eof 
.run subset3.pro
eof
