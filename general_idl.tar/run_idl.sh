#!/bin/sh

idl << eof 
.run cal_5km_bksht_glob_v1_2.pro
eof
