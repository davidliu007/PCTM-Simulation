#!/bin/sh

idl << eof 
.run subset3t2.pro
eof
