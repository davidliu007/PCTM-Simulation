#!/bin/sh

idl << eof 
.comp radview_geo_fix
.comp radview_gps_fix
.comp radview_L1_mon
.comp radview_meo_fix
.run radview_fix_yr_run.pro
eof
